"""
Package for analyzing connectivity.
"""
