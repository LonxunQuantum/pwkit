"""
Package for analyzing coordination environments.
"""
